package ru.sparkguard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Shulker;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class SparkGuard extends JavaPlugin implements Listener {

    /** Данные игрока. Только примитивы и мелкие коллекции - без лишних аллокаций в onMove. */
    private static final class Data {
        final Map<String, Double> vl = new HashMap<>(4);
        final Map<String, Long> lastAlert = new HashMap<>(4);
        boolean bypass;

        // безопасная позиция (примитивы, чтобы не клонировать Location каждый тик)
        World safeWorld;
        double safeX, safeY, safeZ;
        boolean hasSafe;

        long graceUntil, flagUntil;
        double groundY;
        int hover, speedBuf, spoof;

        // NoFall
        // вода
        int waterTicks, waterBuf;
        // Spider
        int riseTicks;

        double fall;
        boolean entityGround;
        boolean pendingNoFall;
        long landTime, lastFallDamage;
        double landFall;

        // KillAura
        final ArrayDeque<Long> hits = new ArrayDeque<>();
        UUID lastTarget;
        long lastHitTime;
        double bigRot;
        long bigRotTime;
        // KillAura v2
        long lastSwingTime;
        boolean hitSwingPending;
        int swings, hitCount;
        final ArrayDeque<Long> switches = new ArrayDeque<>();
        final double[] aimErr = new double[12];
        int aimN, aimI;
        // история позиций игрока (для компенсации лага в Hitbox)
        final double[] hx = new double[8], hy = new double[8], hz = new double[8];
        final long[] ht = new long[8];
        int hi;
        // Timer / Step / NoSlow / InvMove / AutoTotem
        long lastMove, invWindow, popTime;
        double timer, lastH;
        boolean wasGround;
        int noSlowTicks, invCount;
        // Velocity (AntiKnockback)
        boolean kbPending;
        double kbMag, kbMax, kbDx, kbDz, kbSx, kbSz;
        // Scaffold / Nuker
        final ArrayDeque<Long> places = new ArrayDeque<>();
        final ArrayDeque<Long> breaks = new ArrayDeque<>();
        long lastBreakTime, lastBreakKey;
        long setbackUntil;
        double aimTx, aimTz;
        boolean aimHasPos;
        // KillAura v3 (современные читы)
        double lastYawD, lastPitchD;
        long lastRotTime;
        boolean silentPending;
        double hitYawD, hitPitchD;
        long silentTime;
        final double[] gcdBuf = new double[16];
        int gcdN;
        final double[] smoothBuf = new double[8];
        int smoothN;
        final double[] gapBuf = new double[16];
        int gapN;
        final double[] rangeBuf = new double[15];
        int rangeN;
        final long[] heurTime = new long[10];
        long prevRotTime;
        int reachBits, reachN, burstBits, burstN;

        void resetAir() {
            hover = 0;
            speedBuf = 0;
            spoof = 0;
            fall = 0;
            waterTicks = 0;
            waterBuf = 0;
            riseTicks = 0;
        }
    }

    private final Map<UUID, Data> data = new HashMap<>();
    private final Set<UUID> alertsOff = new HashSet<>();
    private volatile double tps = 20.0;
    private double tickAvg = 50.0;
    private volatile List<Player> alertTargets = new ArrayList<>();
    private Set<String> alertOnly = new HashSet<>();
    private String profile = "normal";
    private double nukerExpand;
    private boolean auraSilent, auraGcd, auraSmooth, auraTiming, auraRange, auraUseItem, viaPresent;
    private double auraSilentMin, auraSmoothStd, auraTimingStd;
    private boolean auraReachSoft, auraBurst;
    private double auraSoftReach;
    private int comboNeed, auraSoftNeed, auraBurstNeed;
    private long comboWindowMs;
    private String geyserPrefix = ".";

    // ---- кэш настроек ----
    private double minTps, vlDecay, setbackVl, kickVl;
    private int maxPing, alertCooldown, joinGrace;
    private boolean flyOn, speedOn, reachOn;
    private int maxHover, speedBuffer;
    private double heightLeeway, maxHorizontal, maxReach;
    private boolean auraOn, auraWall, auraSnap, auraHitbox;
    private int auraMaxHits;
    private double auraExpand, auraSnapAngle;
    private boolean auraSwing, auraAim, auraAcc, debug;
    private int auraMaxSwitches, auraAccWindow;
    private double auraAimMean, auraAimStd, auraAccRatio;

    // новые проверки
    private long lastServerTick, lagUntil;
    private boolean timerOn, stepOn, phaseOn, phaseInside, noSlowOn, kbOn;
    private boolean scaffoldOn, scaffoldLook, nukerOn, nukerLook, nukerWall, totemOn, invMoveOn;
    private double timerMax, timerBank, stepMax, phaseRayMin, noSlowMax, kbMinVel, kbMinRatio;
    private double scaffoldExpand, nukerMaxDist, totemMinMs, invMoveSpeed;
    private int noSlowNeed, scaffoldMaxPlaces, nukerMaxBreaks, invMoveClicks;
    private boolean spiderOn, spiderWall;
    private int spiderMaxTicks;
    private double spiderMaxSpeed;
    private boolean waterOn, waterWalkOn, waterSpeedOn;
    private int waterMaxTicks;
    private double waterMaxSpeed;
    private boolean nofallOn, nofallSpoof, nofallDamage;
    private int spoofTicks;
    private double nofallMinFall;
    private String prefix, alertMsg, kickMsg;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        Bukkit.getPluginManager().registerEvents(this, this);

        // раз в секунду: TPS, права bypass, затухание VL (всё остальное - без опросов в onMove)
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            List<Player> recipients = new ArrayList<>();
            for (Player p : new ArrayList<>(Bukkit.getOnlinePlayers())) {
                if (p.hasPermission("sparkguard.alerts") && !alertsOff.contains(p.getUniqueId())) recipients.add(p);
                Data d = data.get(p.getUniqueId());
                if (d == null) continue;
                d.bypass = p.hasPermission("sparkguard.bypass");
                // NoSwing: удар был, а взмаха руки так и не пришло
                if (d.hitSwingPending && !d.bypass && System.currentTimeMillis() - d.lastHitTime > 600) {
                    d.hitSwingPending = false;
                    flag(p, d, "KillAura", 2.0, "NoSwing (удар без взмаха)");
                }
                if (!d.vl.isEmpty()) {
                    d.vl.entrySet().removeIf(en -> {
                        double v = en.getValue() - vlDecay;
                        if (v <= 0) return true;
                        en.setValue(v);
                        return false;
                    });
                }
            }
            alertTargets = recipients;
        }, 20L, 20L);
        // детектор лаг-спайков сервера: после них Timer временно не проверяем
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            long t = System.currentTimeMillis();
            if (lastServerTick != 0) {
                long dt = t - lastServerTick;
                if (dt > 150) lagUntil = t + 3000;
                // скользящее среднее длины тика: реагирует на лаги за ~1 секунду
                tickAvg = tickAvg * 0.9 + Math.min(dt, 500) * 0.1;
                tps = Math.min(20.0, 1000.0 / Math.max(tickAvg, 1.0));
            }
            lastServerTick = t;
        }, 1L, 1L);
        getLogger().info("SparkGuard включён.");
    }

    private void loadSettings() {
        reloadConfig();
        var c = getConfig();
        minTps = c.getDouble("min-tps", 16.0);
        maxPing = c.getInt("max-ping", 350);
        vlDecay = c.getDouble("vl-decay", 0.6);
        setbackVl = c.getDouble("setback-vl", 6.0);
        kickVl = c.getDouble("kick-vl", 25.0);
        alertCooldown = c.getInt("alert-cooldown-ms", 1500);
        joinGrace = c.getInt("join-grace-ms", 3000);

        flyOn = c.getBoolean("checks.fly.enabled", true);
        maxHover = c.getInt("checks.fly.max-hover-ticks", 12);
        heightLeeway = c.getDouble("checks.fly.height-leeway", 0.4);

        speedOn = c.getBoolean("checks.speed.enabled", true);
        maxHorizontal = c.getDouble("checks.speed.max-horizontal", 0.85);
        speedBuffer = c.getInt("checks.speed.buffer", 5);

        reachOn = c.getBoolean("checks.reach.enabled", true);
        maxReach = c.getDouble("checks.reach.max-distance", 3.8);

        auraOn = c.getBoolean("checks.killaura.enabled", true);
        auraMaxHits = c.getInt("checks.killaura.max-hits-per-second", 22);
        auraHitbox = c.getBoolean("checks.killaura.hitbox-check", true);
        auraExpand = c.getDouble("checks.killaura.hitbox-expand", 0.3);
        auraSwing = c.getBoolean("checks.killaura.swing-check", true);
        auraMaxSwitches = c.getInt("checks.killaura.max-switches-per-second", 5);
        auraAim = c.getBoolean("checks.killaura.aim-check", true);
        auraAimMean = c.getDouble("checks.killaura.aim-max-mean", 1.5);
        auraAimStd = c.getDouble("checks.killaura.aim-max-std", 0.5);
        auraAcc = c.getBoolean("checks.killaura.accuracy-check", true);
        auraAccWindow = c.getInt("checks.killaura.accuracy-window", 30);
        auraAccRatio = c.getDouble("checks.killaura.accuracy-ratio", 0.95);
        auraWall = c.getBoolean("checks.killaura.wall-check", true);
        auraSnap = c.getBoolean("checks.killaura.snap-check", true);
        auraSnapAngle = c.getDouble("checks.killaura.snap-angle", 130.0);

        nofallOn = c.getBoolean("checks.nofall.enabled", true);
        nofallSpoof = c.getBoolean("checks.nofall.spoof-check", true);
        spoofTicks = c.getInt("checks.nofall.spoof-ticks", 3);
        nofallDamage = c.getBoolean("checks.nofall.damage-check", true);
        nofallMinFall = c.getDouble("checks.nofall.min-fall-distance", 4.5);

        spiderOn = c.getBoolean("checks.spider.enabled", true);
        spiderMaxTicks = c.getInt("checks.spider.max-rise-ticks", 8);
        spiderMaxSpeed = c.getDouble("checks.spider.max-rise-speed", 0.6);
        spiderWall = c.getBoolean("checks.spider.wall-check", true);

        waterOn = c.getBoolean("checks.waterwalk.enabled", true);
        waterWalkOn = c.getBoolean("checks.waterwalk.walk-check", true);
        waterMaxTicks = c.getInt("checks.waterwalk.max-ticks", 8);
        waterSpeedOn = c.getBoolean("checks.waterwalk.speed-check", true);
        waterMaxSpeed = c.getDouble("checks.waterwalk.max-water-speed", 0.6);

        timerOn = c.getBoolean("checks.timer.enabled", true);
        timerMax = c.getDouble("checks.timer.max-balance-ms", 300);
        timerBank = c.getDouble("checks.timer.bank-ms", 300);
        stepOn = c.getBoolean("checks.step.enabled", true);
        stepMax = c.getDouble("checks.step.max-step-height", 0.7);
        phaseOn = c.getBoolean("checks.phase.enabled", true);
        phaseInside = c.getBoolean("checks.phase.inside-check", true);
        phaseRayMin = c.getDouble("checks.phase.ray-min-distance", 1.0);
        noSlowOn = c.getBoolean("checks.noslow.enabled", true);
        noSlowMax = c.getDouble("checks.noslow.max-speed", 0.16);
        noSlowNeed = c.getInt("checks.noslow.ticks", 6);
        kbOn = c.getBoolean("checks.velocity.enabled", true);
        kbMinVel = c.getDouble("checks.velocity.min-velocity", 0.3);
        kbMinRatio = c.getDouble("checks.velocity.min-ratio", 0.15);
        scaffoldOn = c.getBoolean("checks.scaffold.enabled", true);
        scaffoldLook = c.getBoolean("checks.scaffold.look-check", true);
        scaffoldExpand = c.getDouble("checks.scaffold.look-expand", 0.3);
        scaffoldMaxPlaces = c.getInt("checks.scaffold.max-places-per-second", 15);
        nukerOn = c.getBoolean("checks.nuker.enabled", true);
        nukerMaxBreaks = c.getInt("checks.nuker.max-breaks-per-second", 12);
        nukerMaxDist = c.getDouble("checks.nuker.max-distance", 6.0);
        nukerLook = c.getBoolean("checks.nuker.look-check", true);
        nukerWall = c.getBoolean("checks.nuker.wall-check", true);
        totemOn = c.getBoolean("checks.autototem.enabled", true);
        totemMinMs = c.getDouble("checks.autototem.min-reaction-ms", 100);
        invMoveOn = c.getBoolean("checks.invmove.enabled", true);
        invMoveSpeed = c.getDouble("checks.invmove.min-speed", 0.2);
        invMoveClicks = c.getInt("checks.invmove.clicks", 3);

        auraSilent = c.getBoolean("checks.killaura.silent-check", true);
        auraSilentMin = c.getDouble("checks.killaura.silent-min-angle", 15.0);
        auraGcd = c.getBoolean("checks.killaura.gcd-check", true);
        geyserPrefix = c.getString("checks.killaura.geyser-prefix", ".");
        auraSmooth = c.getBoolean("checks.killaura.smooth-check", true);
        auraSmoothStd = c.getDouble("checks.killaura.smooth-max-std", 0.05);
        auraTiming = c.getBoolean("checks.killaura.timing-check", true);
        auraTimingStd = c.getDouble("checks.killaura.timing-max-std", 0.3);
        auraRange = c.getBoolean("checks.killaura.range-check", true);
        auraUseItem = c.getBoolean("checks.killaura.use-item-check", true);
        comboNeed = c.getInt("checks.killaura.combo-need", 3);
        comboWindowMs = c.getLong("checks.killaura.combo-window-s", 90) * 1000L;
        // ViaVersion: 1.8-клиенты бьют, блокируя мечом - проверка "удар при использовании предмета" им не подходит
        viaPresent = Bukkit.getPluginManager().getPlugin("ViaVersion") != null
                || Bukkit.getPluginManager().getPlugin("ViaRewind") != null;
        auraReachSoft = c.getBoolean("checks.killaura.reach-soft-check", true);
        auraSoftReach = c.getDouble("checks.killaura.reach-soft-distance", 3.35);
        auraSoftNeed = c.getInt("checks.killaura.reach-soft-need", 5);
        auraBurst = c.getBoolean("checks.killaura.burst-check", true);
        auraBurstNeed = c.getInt("checks.killaura.burst-need", 8);
        nukerExpand = c.getDouble("checks.nuker.look-expand", 0.3);
        alertOnly = new HashSet<>(c.contains("alert-only-checks")
                ? c.getStringList("alert-only-checks")
                : List.of("InvMove", "AutoTotem", "AuraRot", "AuraSmooth", "AuraTiming", "AuraRange",
                          "AuraSnap", "AuraReach", "AuraAccuracy", "AuraBurst"));

        // профиль: strict - строже, relaxed - мягче
        profile = c.getString("profile", "normal").toLowerCase();
        double pm = profile.equals("strict") ? 0.85 : profile.equals("relaxed") ? 1.2 : 1.0;
        setbackVl *= pm;
        kickVl *= pm;
        maxHorizontal *= pm;
        heightLeeway *= pm;
        maxHover = (int) Math.round(maxHover * pm);
        maxReach += pm - 1.0;
        if (pm < 1.0) {                 // strict: меньше слабых признаков для комбо, ближе мягкий порог досягаемости
            comboNeed = Math.max(2, comboNeed - 1);
            auraSoftReach -= 0.1;
        } else if (pm > 1.0) {          // relaxed
            comboNeed += 1;
            auraSoftReach += 0.15;
        }

        prefix = c.getString("messages.prefix", "&b[SparkGuard] &f");
        alertMsg = c.getString("messages.alert", "&e%player% &fзаподозрен в &c%check% &7(%info%) &fVL: &c%vl%");
        kickMsg = c.getString("messages.kick", "&cВы были кикнуты SparkGuard.");
    }

    // ================= утилиты =================

    private Data data(Player p) {
        return data.computeIfAbsent(p.getUniqueId(), k -> new Data());
    }

    private Component color(String s) {
        return LegacyComponentSerializer.legacyAmpersand().deserialize(s);
    }

    private void grace(Data d, long ms) {
        d.graceUntil = Math.max(d.graceUntil, System.currentTimeMillis() + ms);
        d.resetAir();
    }

    private static void setSafe(Data d, World w, Location l) {
        d.safeWorld = w;
        d.safeX = l.getX();
        d.safeY = l.getY();
        d.safeZ = l.getZ();
        d.hasSafe = true;
    }

    /** Дёшево: никаких опросов сервера (TPS и bypass кэшируются раз в секунду). */
    private boolean skip(Player p, Data d) {
        if (d.bypass || tps < minTps) return true;
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return true;
        if (p.getAllowFlight() || p.isFlying() || p.isInsideVehicle() || p.isDead()) return true;
        return p.getPing() > maxPing;
    }

    private void flag(Player p, Data d, String check, double add, String info) {
        long now = System.currentTimeMillis();
        double v = d.vl.merge(check, add, Double::sum);
        d.flagUntil = now + 3000;

        if (now - d.lastAlert.getOrDefault(check, 0L) >= alertCooldown) {
            d.lastAlert.put(check, now);
            Component c = color(prefix + alertMsg
                    .replace("%player%", p.getName())
                    .replace("%check%", check)
                    .replace("%info%", info)
                    .replace("%vl%", String.format("%.1f", v)));
            for (Player op : alertTargets) op.sendMessage(c);
            Bukkit.getConsoleSender().sendMessage(c);
        }

        if (alertOnly.contains(check)) return;   // эвристики с риском ложных: только оповещение

        if (v >= kickVl) {
            d.vl.clear();
            p.kick(color(kickMsg));
        } else if (v >= setbackVl && d.hasSafe && d.safeWorld != null && now > d.setbackUntil) {
            d.setbackUntil = now + 800;
            Location cur = p.getLocation();
            Location target = new Location(d.safeWorld, d.safeX, d.safeY, d.safeZ, cur.getYaw(), cur.getPitch());
            // телепорт на следующий тик - безопаснее, чем прямо внутри PlayerMoveEvent
            Bukkit.getScheduler().runTask(this, () -> {
                if (p.isOnline()) p.teleport(target, PlayerTeleportEvent.TeleportCause.PLUGIN);
            });
            grace(d, 800);
        }
    }

    /** Есть ли твёрдый блок под ногами на заданном смещении. Незагруженные чанки считаем твёрдыми (не грузим их). */
    private boolean solidBelow(World w, double x, double y, double z, double off) {
        int by = (int) Math.floor(y + off);
        int x0 = (int) Math.floor(x - 0.3), x1 = (int) Math.floor(x + 0.3);
        int z0 = (int) Math.floor(z - 0.3), z1 = (int) Math.floor(z + 0.3);
        int lcx = Integer.MIN_VALUE, lcz = Integer.MIN_VALUE;
        for (int bx = x0; bx <= x1; bx++) {
            for (int bz = z0; bz <= z1; bz++) {
                int cx = bx >> 4, cz = bz >> 4;
                if (cx != lcx || cz != lcz) {
                    if (!w.isChunkLoaded(cx, cz)) return true;
                    lcx = cx;
                    lcz = cz;
                }
                if (!w.getBlockAt(bx, by, bz).isPassable()) return true;
            }
        }
        return false;
    }

    private boolean entityBelow(Location loc) {
        return !loc.getWorld().getNearbyEntities(loc, 1.2, 1.0, 1.2,
                en -> en instanceof Boat || en instanceof Shulker).isEmpty();
    }

    private static boolean mediumBlock(Material m) {
        switch (m) {
            case WATER, LAVA, COBWEB, POWDER_SNOW, HONEY_BLOCK, SLIME_BLOCK, BUBBLE_COLUMN,
                 SCAFFOLDING, SWEET_BERRY_BUSH, BIG_DRIPLEAF, POINTED_DRIPSTONE:
                return true;
            default:
                return Tag.CLIMBABLE.isTagged(m) || Tag.BEDS.isTagged(m);
        }
    }

    /** Среда, где обычная физика не работает. Вызывается только когда игрок в воздухе. */
    private boolean specialMedium(Player p, Location loc) {
        if (p.isInWater()) return true;
        World w = loc.getWorld();
        int x = loc.getBlockX(), y = loc.getBlockY(), z = loc.getBlockZ();
        return mediumBlock(w.getBlockAt(x, (int) Math.floor(loc.getY() - 0.5), z).getType())
                || mediumBlock(w.getBlockAt(x, y, z).getType())
                || mediumBlock(w.getBlockAt(x, y + 1, z).getType());
    }

    private Material blockUnder(Location l) {
        return l.getWorld().getBlockAt(l.getBlockX(), (int) Math.floor(l.getY() - 0.5), l.getBlockZ()).getType();
    }

    private int amp(Player p, PotionEffectType t) {
        PotionEffect e = p.getPotionEffect(t);
        return e == null ? -1 : e.getAmplifier();
    }

    // ================= движение =================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        Player p = e.getPlayer();
        Data d = data(p);

        // анализ поворотов камеры (Snap, Silent, GCD, Smooth)
        if (auraOn) trackRotation(p, d, from, to);

        double dx = to.getX() - from.getX();
        double dy = to.getY() - from.getY();
        double dz = to.getZ() - from.getZ();
        if (dx == 0 && dy == 0 && dz == 0) return;   // только поворот головы
        World w = to.getWorld();
        if (w != from.getWorld()) return;

        long now = System.currentTimeMillis();
        int hi = d.hi = (d.hi + 1) & 7;
        d.hx[hi] = to.getX();
        d.hy[hi] = to.getY();
        d.hz[hi] = to.getZ();
        d.ht[hi] = now;
        long elapsed = d.lastMove == 0 ? 50 : now - d.lastMove;
        d.lastMove = now;
        d.lastH = Math.hypot(dx, dz);

        // Velocity: сколько игрок реально сместился вдоль вектора отбрасывания
        if (d.kbPending) {
            double disp = (to.getX() - d.kbSx) * d.kbDx + (to.getZ() - d.kbSz) * d.kbDz;
            if (disp > d.kbMax) d.kbMax = disp;
        }

        if (skip(p, d)) {
            d.resetAir();
            setSafe(d, w, to);
            return;
        }

        // Timer: баланс "время пакетов" против реального времени
        if (timerOn) {
            if (now < lagUntil || now < d.graceUntil) {
                d.timer = 0;
            } else {
                d.timer += 50 - elapsed;
                if (d.timer < -timerBank) d.timer = -timerBank;
                if (d.timer > timerMax) {
                    flag(p, d, "Timer", 1.5, String.format("баланс +%.0f мс", d.timer));
                    d.timer = 0;
                }
            }
        }

        boolean ground = solidBelow(w, to.getX(), to.getY(), to.getZ(), -0.1);
        d.entityGround = false;
        // лодки/шалкеры проверяем только если игрок почти не двигается по вертикали
        if (!ground && dy > -0.1 && dy < 0.1 && entityBelow(to)) {
            ground = true;
            d.entityGround = true;
        }
        boolean prevGround = d.wasGround;
        d.wasGround = ground;

        boolean inGrace = now < d.graceUntil;
        // вода проверяется ДО исключений среды, иначе "ходьба по воде" проходит мимо всех проверок
        if (waterOn && !inGrace && !p.isGliding() && !p.isRiptiding()) {
            checkWater(p, d, to, ground, Math.hypot(dx, dz), dy);
        }

        if (inGrace || p.isGliding() || p.isRiptiding() || p.isClimbing() || p.isSwimming()
                || (!ground && specialMedium(p, to))) {
            d.resetAir();
            d.groundY = to.getY();
            if (ground) setSafe(d, w, to);
            return;
        }

        if (phaseOn) checkPhase(p, d, from, to, w, dx, dy, dz);
        if (stepOn && ground && prevGround && !d.entityGround && dy > stepMax) {
            flag(p, d, "Step", 2.0, String.format("подъём %.2f за тик", dy));
        }
        if (noSlowOn) checkNoSlow(p, d, to, ground && prevGround, dx, dz);

        if (ground) {
            if (d.fall > 0) {
                onLanding(p, d, to, now);
                d.fall = 0;
            }
            d.groundY = to.getY();
            d.hover = 0;
            d.spoof = 0;
            d.riseTicks = 0;
            if (now > d.flagUntil) setSafe(d, w, to);
        } else {
            if (dy < 0) d.fall -= dy;
            if (nofallOn && nofallSpoof) checkSpoof(p, d, to);
            if (flyOn) checkFly(p, d, to, dy);
            if (spiderOn) checkSpider(p, d, to, dy);
        }

        if (speedOn) {
            double h = Math.hypot(dx, dz);
            double limit = maxHorizontal;
            boolean over = false;
            if (h > maxHorizontal) {          // тяжёлые расчёты только при подозрении
                limit = speedLimit(p, to);
                over = h > limit;
            }
            if (over) {
                if (++d.speedBuf >= speedBuffer) {
                    flag(p, d, "Speed", 1.0, String.format("%.2f > %.2f", h, limit));
                    d.speedBuf = 0;
                }
            } else if (d.speedBuf > 0) {
                d.speedBuf--;
            }
        }
    }

    private double speedLimit(Player p, Location to) {
        double limit = maxHorizontal;
        int sp = amp(p, PotionEffectType.SPEED);
        if (sp >= 0) limit *= 1.0 + 0.2 * (sp + 1);
        double ws = p.getWalkSpeed() / 0.2;
        if (ws > 1.0) limit *= ws;
        Material under = blockUnder(to);
        if (Tag.ICE.isTagged(under)) limit *= 1.8;
        else if (under == Material.SOUL_SAND || under == Material.SOUL_SOIL) limit *= 1.5;
        return limit;
    }

    private void checkFly(Player p, Data d, Location to, double dy) {
        if (p.hasPotionEffect(PotionEffectType.LEVITATION) || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
            d.hover = 0;
            return;
        }
        double maxRise = 1.25 + heightLeeway;
        int jump = amp(p, PotionEffectType.JUMP_BOOST);
        if (jump >= 0) maxRise += 0.55 * (jump + 1) + 0.15 * (jump + 1) * (jump + 1);
        double rise = to.getY() - d.groundY;
        if (rise > maxRise) {
            flag(p, d, "Fly", 2.0, String.format("высота +%.2f", rise));
        }
        if (dy > -0.03 && dy < 0.03) {
            if (++d.hover > maxHover) {
                flag(p, d, "Fly", 1.5, "зависание");
                d.hover = 0;
            }
        } else if (d.hover > 0) {
            d.hover--;
        }
    }

    // ================= Spider =================

    private void checkSpider(Player p, Data d, Location to, double dy) {
        if (p.hasPotionEffect(PotionEffectType.LEVITATION)) {
            d.riseTicks = 0;
            return;
        }
        int jb = amp(p, PotionEffectType.JUMP_BOOST);

        // 1) подъём за один тик быстрее, чем возможно в прыжке (ванилла: 0.42)
        double maxUp = spiderMaxSpeed + 0.1 * (jb + 1);
        if (dy > maxUp) {
            flag(p, d, "Spider", 1.5, String.format("подъём %.2f/тик", dy));
        }

        // 2) подъём дольше, чем длится прыжок (~6 тиков), да ещё вдоль стены
        if (dy > 0.005) {
            int limit = spiderMaxTicks + (jb >= 0 ? 3 * (jb + 1) : 0);
            if (++d.riseTicks > limit && (!spiderWall || wallNear(to))) {
                flag(p, d, "Spider", 2.0, "лазание по стене, " + d.riseTicks + " тиков");
                d.riseTicks = 0;
            }
        } else {
            d.riseTicks = 0;
        }
    }

    /** Есть ли твёрдый блок вплотную сбоку на уровне ног или головы. */
    private boolean wallNear(Location l) {
        World w = l.getWorld();
        double x = l.getX(), z = l.getZ();
        double[] offs = {0.45, -0.45};
        double[] heights = {0.1, 1.0};
        for (double h : heights) {
            int by = (int) Math.floor(l.getY() + h);
            for (double o : offs) {
                if (!w.getBlockAt((int) Math.floor(x + o), by, (int) Math.floor(z)).isPassable()) return true;
                if (!w.getBlockAt((int) Math.floor(x), by, (int) Math.floor(z + o)).isPassable()) return true;
            }
        }
        return false;
    }

    // ================= Вода: Jesus / WaterWalk / WaterSpeed =================

    private void checkWater(Player p, Data d, Location to, boolean ground, double h, double dy) {
        if (p.isInWater()) {
            d.waterTicks = 0;
            // слишком быстрое плавание (Dolphin's Grace разрешён)
            if (waterSpeedOn && h > waterMaxSpeed && !p.hasPotionEffect(PotionEffectType.DOLPHINS_GRACE)) {
                if (++d.waterBuf >= 4) {
                    flag(p, d, "WaterSpeed", 1.0, String.format("%.2f > %.2f", h, waterMaxSpeed));
                    d.waterBuf = 0;
                }
            } else if (d.waterBuf > 0) {
                d.waterBuf--;
            }
            return;
        }
        d.waterBuf = 0;
        if (!waterWalkOn || ground || dy < -0.25
                || p.hasPotionEffect(PotionEffectType.LEVITATION)
                || p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) {
            d.waterTicks = 0;
            return;
        }
        // игрок не в воде, ни на чём твёрдом, а прямо под ним поверхность воды - Jesus
        Block b = to.getWorld().getBlockAt(to.getBlockX(), (int) Math.floor(to.getY() - 0.2), to.getBlockZ());
        if (b.getType() == Material.WATER) {
            if (++d.waterTicks >= waterMaxTicks) {
                flag(p, d, "WaterWalk", 2.0, "ходьба по воде, " + d.waterTicks + " тиков");
                d.waterTicks = 0;
            }
        } else if (d.waterTicks > 0) {
            d.waterTicks--;
        }
    }

    // ================= NoFall =================

    /** Клиент говорит "я на земле", хотя под ним явно воздух. */
    @SuppressWarnings("deprecation")
    private void checkSpoof(Player p, Data d, Location to) {
        if (p.isOnGround() && clearlyAirborne(to)) {
            if (++d.spoof >= spoofTicks) {
                flag(p, d, "NoFall", 1.5, "ложный onGround");
                d.spoof = 0;
            }
        } else if (d.spoof > 0) {
            d.spoof--;
        }
    }

    private boolean clearlyAirborne(Location l) {
        World w = l.getWorld();
        double x = l.getX(), y = l.getY(), z = l.getZ();
        return !solidBelow(w, x, y, z, -0.1) && !solidBelow(w, x, y, z, -0.6)
                && !solidBelow(w, x, y, z, -1.1) && !entityBelow(l);
    }

    /** Приземление: бонус-грация на слайме/кроватях и отложенная проверка "был ли урон от падения". */
    private void onLanding(Player p, Data d, Location to, long now) {
        Material below = blockUnder(to);
        if (below == Material.SLIME_BLOCK || Tag.BEDS.isTagged(below)) {
            d.graceUntil = Math.max(d.graceUntil, now + 4000);   // отскок
            return;
        }
        if (!nofallOn || !nofallDamage) return;
        double fall = d.fall;
        if (fall < nofallMinFall || d.entityGround) return;
        if (below == Material.HAY_BLOCK || below == Material.HONEY_BLOCK || below == Material.SCAFFOLDING
                || below == Material.COBWEB || below == Material.POWDER_SNOW
                || below == Material.SWEET_BERRY_BUSH || Tag.CLIMBABLE.isTagged(below)) return;
        if (p.getNoDamageTicks() > 0 || p.isInvulnerable() || fallProtected(p, fall)) return;

        d.pendingNoFall = true;
        d.landTime = now;
        d.landFall = fall;
        Bukkit.getScheduler().runTaskLater(this, () -> verifyFall(p), 4L);
    }

    private boolean fallProtected(Player p, double fall) {
        if (p.hasPotionEffect(PotionEffectType.SLOW_FALLING)) return true;
        if (amp(p, PotionEffectType.RESISTANCE) >= 4) return true;
        int jb = amp(p, PotionEffectType.JUMP_BOOST);
        if (jb >= 0) fall -= jb + 1;
        ItemStack boots = p.getInventory().getBoots();
        if (boots != null && boots.getType() != Material.AIR) {
            fall -= boots.getEnchantmentLevel(Enchantment.FEATHER_FALLING) * 0.75;
        }
        return fall < nofallMinFall;
    }

    private void verifyFall(Player p) {
        if (!p.isOnline()) return;
        Data d = data.get(p.getUniqueId());
        if (d == null || !d.pendingNoFall) return;
        d.pendingNoFall = false;
        if (d.bypass || p.isDead() || d.lastFallDamage >= d.landTime - 100) return;
        flag(p, d, "NoFall", 2.5, String.format("упал %.1f бл. без урона", d.landFall));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onDamage(EntityDamageEvent e) {
        if (e.getCause() == EntityDamageEvent.DamageCause.FALL && e.getEntity() instanceof Player p) {
            Data d = data.get(p.getUniqueId());
            if (d != null) d.lastFallDamage = System.currentTimeMillis();
        }
    }

    // ================= бой: Reach + KillAura =================

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        if (e.getCause() != EntityDamageEvent.DamageCause.ENTITY_ATTACK) return;
        Data d = data(p);
        if (skip(p, d)) return;

        Entity target = e.getEntity();
        BoundingBox box = target.getBoundingBox();
        Location eye = p.getEyeLocation();
        Vector eyeVec = eye.toVector();
        double cx = Math.max(box.getMinX(), Math.min(eyeVec.getX(), box.getMaxX()));
        double cy = Math.max(box.getMinY(), Math.min(eyeVec.getY(), box.getMaxY()));
        double cz = Math.max(box.getMinZ(), Math.min(eyeVec.getZ(), box.getMaxZ()));
        Vector closest = new Vector(cx, cy, cz);
        double dist = closest.distance(eyeVec);
        // дистанция с компенсацией пинга (по недавним позициям цели) - её используем во всех проверках
        double ldist = target instanceof Player ? lagCompDist(p, target, eyeVec, dist) : dist;

        if (reachOn && ldist > maxReach) {
            e.setCancelled(true);
            flag(p, d, "Reach", 1.5, String.format("%.2f блока", ldist));
            return;
        }
        if (auraOn && killAura(p, d, target, eye, eyeVec, box, closest, dist, ldist)) {
            e.setCancelled(true);
        }
    }

    /** Итог проверок одного удара: флагуем один раз по самому серьёзному нарушению, а не по каждому. */
    private static final class Verdict {
        double vl;
        String why = "";
        boolean cancel;
        int count;

        void add(double v, String w, boolean c) {
            count++;
            if (v > vl) {
                vl = v;
                why = w;
            }
            if (c) cancel = true;
        }
    }

    /** Новая схватка: выборки из прошлой схватки не должны смешиваться с новой. */
    private void resetFight(Data d) {
        d.aimN = 0;
        d.aimI = 0;
        d.aimHasPos = false;
        d.rangeN = 0;
        d.gapN = 0;
        d.reachBits = 0;
        d.reachN = 0;
        d.burstBits = 0;
        d.burstN = 0;
        d.gcdN = 0;
        d.smoothN = 0;
        d.silentPending = false;
        d.switches.clear();
        d.hits.clear();
    }

    /** @return true, если удар надо отменить */
    private boolean killAura(Player p, Data d, Entity target, Location eye, Vector eyeVec,
                             BoundingBox box, Vector closest, double dist, double ldist) {
        long now = System.currentTimeMillis();
        Verdict v = new Verdict();
        UUID tid = target.getUniqueId();
        Vector look = eye.getDirection();
        long gap = now - d.lastHitTime;
        if (gap > 6000) resetFight(d);

        // 0) UseItem: ванильный клиент не может бить, пока ест / тянет лук / держит щит
        if (auraUseItem && !viaPresent && p.isHandRaised()) {
            flag(p, d, "AuraUseItem", 1.5, "удар во время использования предмета");
            v.cancel = true;
        }

        // 1) Multi (несколько целей за тик) и Switch (слишком частая смена цели)
        boolean switched = d.lastTarget != null && !d.lastTarget.equals(tid);
        if (switched && gap < 40) v.add(3.0, "Multi (несколько целей за тик)", true);
        if (switched) d.switches.addLast(now);
        while (!d.switches.isEmpty() && now - d.switches.peekFirst() > 1000) d.switches.pollFirst();
        if (d.switches.size() >= auraMaxSwitches) {
            v.add(2.0, "Switch (смен цели/сек: " + d.switches.size() + ")", false);
            d.heurTime[6] = now;
            d.switches.clear();
        }
        d.lastTarget = tid;
        d.lastHitTime = now;

        // 2) повороты прямо перед ударом: Silent (возврат взгляда) и Burst (рывок из покоя)
        double lm = now - d.lastRotTime < 100
                ? Math.sqrt(d.lastYawD * d.lastYawD + d.lastPitchD * d.lastPitchD) : 0;
        if (auraSilent && lm >= auraSilentMin) {
            d.silentPending = true;
            d.hitYawD = d.lastYawD;
            d.hitPitchD = d.lastPitchD;
            d.silentTime = now;
        }
        if (auraBurst && lm >= 10.0) {
            boolean fromRest = d.lastRotTime - d.prevRotTime > 600;
            d.burstBits = ((d.burstBits << 1) | (fromRest ? 1 : 0)) & 0x3FF;
            if (d.burstN < 10) d.burstN++;
            if (d.burstN >= 10 && Integer.bitCount(d.burstBits) >= auraBurstNeed) {
                heuristic(p, d, 9, "AuraBurst",
                        Integer.bitCount(d.burstBits) + " из 10 рывков камеры - из полного покоя прямо перед ударом");
                d.burstBits = 0;
                d.burstN = 0;
            }
        }

        // 3) Timing: удары через одинаковое число тиков (идеальная синхронизация с кулдауном)
        if (auraTiming) {
            if (gap >= 250 && gap <= 2500) {
                d.gapBuf[d.gapN++] = Math.round(gap / 50.0);
                if (d.gapN >= d.gapBuf.length) {
                    d.gapN = 0;
                    double m = mean(d.gapBuf), sd = std(d.gapBuf, m);
                    if (m >= 5 && sd < auraTimingStd) {
                        heuristic(p, d, 2, "AuraTiming", String.format("интервал %.1f тиков, σ %.2f", m, sd));
                    }
                }
            } else {
                d.gapN = 0;
            }
        }

        // 4) Range (все удары у границы) и Reach-soft (частые удары чуть дальше ванильной досягаемости)
        if (target instanceof Player) {
            if (auraRange) {
                d.rangeBuf[d.rangeN++] = ldist;
                if (d.rangeN >= d.rangeBuf.length) {
                    d.rangeN = 0;
                    double m = mean(d.rangeBuf), sd = std(d.rangeBuf, m);
                    if (m > 2.8 && sd < 0.12) {
                        heuristic(p, d, 3, "AuraRange", String.format("все удары на %.2f бл., σ %.2f", m, sd));
                    }
                }
            }
            if (auraReachSoft) {
                d.reachBits = ((d.reachBits << 1) | (ldist > auraSoftReach ? 1 : 0)) & 0xFFF;
                if (d.reachN < 12) d.reachN++;
                if (d.reachN >= 12 && Integer.bitCount(d.reachBits) >= auraSoftNeed) {
                    heuristic(p, d, 7, "AuraReach", String.format("%d из 12 ударов дальше %.2f бл.",
                            Integer.bitCount(d.reachBits), auraSoftReach));
                    d.reachBits = 0;
                    d.reachN = 0;
                }
            }
            d.hitCount++;                       // для Accuracy
        }

        // 5) учёт для NoSwing
        if (auraSwing) d.hitSwingPending = now - d.lastSwingTime >= 150;

        // 6) Частота ударов
        d.hits.addLast(now);
        while (!d.hits.isEmpty() && now - d.hits.peekFirst() > 1000) d.hits.pollFirst();
        if (d.hits.size() > auraMaxHits) v.add(2.0, "ударов/сек: " + d.hits.size(), true);

        // 7) Hitbox с компенсацией лага (учитываем прошлые позиции цели)
        if (auraHitbox) {
            double expand = auraExpand + Math.min(p.getPing(), 300) / 50.0 * 0.05;
            if (!hitsTarget(p, target, box, eyeVec, look, dist, expand, now)) {
                v.add(2.0, "Hitbox (бьёт не глядя на цель)", true);
            }
        }

        // угол между взглядом и центром цели - для Snap и Aim
        double angle = -1;
        if (auraSnap || auraAim) {
            Vector toCenter = box.getCenter().subtract(eyeVec);
            if (toCenter.lengthSquared() > 0.0001) {
                angle = Math.toDegrees(look.angle(toCenter.normalize()));
            }
        }

        // 8) Snap: резкий доворот перед ударом + точное наведение
        if (auraSnap && angle >= 0 && angle < 8.0 && now - d.bigRotTime < 100) {
            heuristic(p, d, 5, "AuraSnap", String.format("доворот %.0f° и точное наведение", d.bigRot));
        }

        // 9) Aim: "слишком идеальное" наведение по движущимся целям
        if (auraAim && angle >= 0 && dist > 1.2 && target instanceof org.bukkit.entity.LivingEntity) {
            Vector ac = box.getCenter();
            boolean moved = !d.aimHasPos || Math.hypot(ac.getX() - d.aimTx, ac.getZ() - d.aimTz) > 0.25;
            d.aimTx = ac.getX();
            d.aimTz = ac.getZ();
            d.aimHasPos = true;
            if (moved) {
                d.aimErr[d.aimI] = angle;
                d.aimI = (d.aimI + 1) % d.aimErr.length;
                if (d.aimN < d.aimErr.length) d.aimN++;
                if (d.aimN >= d.aimErr.length) {
                    double mean = mean(d.aimErr);
                    double std = std(d.aimErr, mean);
                    if (mean < auraAimMean && std < auraAimStd) {
                        v.add(2.0, String.format("Aim (ср. %.2f°, σ %.2f°)", mean, std), false);
                        d.heurTime[4] = now;
                        d.aimN = 0;
                        d.aimI = 0;
                    }
                }
            }
        }

        // 10) Wall: удар через твёрдые блоки (дорогой rayTrace - только если удар ещё не признан плохим)
        if (auraWall && dist > 0.5 && !v.cancel) {
            Vector dir = closest.clone().subtract(eyeVec).normalize();
            RayTraceResult br = p.getWorld().rayTraceBlocks(eye, dir, dist, FluidCollisionMode.NEVER, true);
            if (br != null && br.getHitPosition().distance(eyeVec) < dist - 0.3) {
                v.add(2.0, "Wall (удар через блок)", true);
            }
        }

        if (debug) {
            getLogger().info(String.format("[debug] %s -> %s dist=%.2f lag=%.2f angle=%.2f ping=%d aimN=%d acc=%d/%d",
                    p.getName(), target.getName(), dist, ldist, angle, p.getPing(), d.aimN, d.hitCount, d.swings));
        }

        // один флаг на удар: самое серьёзное нарушение, остальные чуть добавляют
        if (v.vl > 0) {
            flag(p, d, "KillAura", Math.min(v.vl + 0.5 * (v.count - 1), 4.0),
                    v.count > 1 ? v.why + " +" + (v.count - 1) + " др." : v.why);
        }
        return v.cancel;
    }

    /** Попадает ли луч взгляда в хитбокс цели - сейчас или в одной из её недавних позиций (лаг). */
    private boolean hitsTarget(Player attacker, Entity target, BoundingBox box, Vector eyeVec,
                               Vector look, double dist, double expand, long now) {
        double reach = dist + 2.0;
        if (box.clone().expand(expand).rayTrace(eyeVec, look, reach) != null) return true;
        if (target instanceof Player tp) {
            Data td = data.get(tp.getUniqueId());
            if (td != null) {
                long window = Math.min(attacker.getPing(), 300) + 150;
                double hw = target.getWidth() / 2.0, h = target.getHeight();
                for (int i = 0; i < td.ht.length; i++) {
                    if (td.ht[i] == 0 || now - td.ht[i] > window) continue;
                    BoundingBox b = new BoundingBox(
                            td.hx[i] - hw - expand, td.hy[i] - expand, td.hz[i] - hw - expand,
                            td.hx[i] + hw + expand, td.hy[i] + h + expand, td.hz[i] + hw + expand);
                    if (b.rayTrace(eyeVec, look, reach) != null) return true;
                }
            }
        }
        return false;
    }

    // ================= KillAura: анализ поворотов (современные читы) =================

    private boolean isBedrock(Player p) {
        return !geyserPrefix.isEmpty() && p.getName().startsWith(geyserPrefix);
    }

    private void trackRotation(Player p, Data d, Location from, Location to) {
        double yawD = ((to.getYaw() - from.getYaw()) % 360 + 540) % 360 - 180;
        double pitchD = to.getPitch() - from.getPitch();
        if (yawD == 0 && pitchD == 0) return;
        long now = System.currentTimeMillis();
        long gapRot = d.lastRotTime == 0 ? 9999 : now - d.lastRotTime;
        double rot = Math.sqrt(yawD * yawD + pitchD * pitchD);

        // Snap: резкий доворот
        if (auraSnap && rot > auraSnapAngle) {
            d.bigRot = rot;
            d.bigRotTime = now;
        }

        // Silent rotation: после удара взгляд сразу вернулся туда, где был до него
        if (d.silentPending) {
            if (now - d.silentTime > 200) {
                d.silentPending = false;
            } else if (rot > 2.0) {
                d.silentPending = false;
                double hitMag = Math.sqrt(d.hitYawD * d.hitYawD + d.hitPitchD * d.hitPitchD);
                double dot = (d.hitYawD * yawD + d.hitPitchD * pitchD) / (hitMag * rot);
                double ratio = rot / hitMag;
                if (dot < -0.9 && ratio > 0.8 && ratio < 1.25) {
                    flag(p, d, "AuraSilent", 2.0, String.format("поворот на %.0f° и мгновенный возврат", hitMag));
                }
            }
        }
        d.lastYawD = yawD;
        d.lastPitchD = pitchD;
        d.prevRotTime = d.lastRotTime;
        d.lastRotTime = now;

        // дальше - только в бою (был удар за последние 2.5 с) и без лагов
        if (now - d.lastHitTime > 2500 || tps < minTps || d.bypass) {
            d.gcdN = 0;
            d.smoothN = 0;
            return;
        }

        // GCD: повороты мыши кратны шагу чувствительности. Читы шлют "произвольные" углы
        if (auraGcd && !isBedrock(p)) {
            double ap = Math.abs(pitchD);
            if (ap > 0.01 && ap < 60.0 && Math.abs(to.getPitch()) < 85.0) {
                d.gcdBuf[d.gcdN++] = ap;
                if (d.gcdN >= d.gcdBuf.length) {
                    d.gcdN = 0;
                    double g = d.gcdBuf[0];
                    for (int i = 1; i < d.gcdBuf.length && g > 0.0045; i++) g = gcd(g, d.gcdBuf[i]);
                    if (g < 0.0045) {
                        heuristic(p, d, 0, "AuraRot", String.format("повороты не кратны шагу мыши (НОД %.4f)", g));
                    }
                }
            }
        }

        // Smooth: человек не поворачивает камеру с постоянным ускорением или идеальным затуханием
        if (auraSmooth && !isBedrock(p)) {
            if (Math.abs(yawD) <= 1.0 || gapRot >= 120) d.smoothN = 0;
            if (Math.abs(yawD) > 1.0) {
                d.smoothBuf[d.smoothN++] = yawD;
                if (d.smoothN >= d.smoothBuf.length) {
                    d.smoothN = 0;
                    if (tooSmooth(d.smoothBuf)) {
                        heuristic(p, d, 1, "AuraSmooth", "слишком гладкие повороты камеры");
                    }
                }
            }
        }
    }

    /** Слабый признак: сам по себе только оповещение, но несколько разных за окно времени = нарушение. */
    private void heuristic(Player p, Data d, int idx, String name, String info) {
        long now = System.currentTimeMillis();
        flag(p, d, name, 1.0, info);
        d.heurTime[idx] = now;
        int n = 0;
        for (long t : d.heurTime) {
            if (t != 0 && now - t < comboWindowMs) n++;
        }
        if (n >= comboNeed) {
            Arrays.fill(d.heurTime, 0L);
            flag(p, d, "KillAura", 3.0, "Комбо подозрительных признаков: " + n);
        }
    }

    private boolean tooSmooth(double[] y) {
        int n = y.length;
        boolean pos = y[0] > 0;
        for (double v : y) {
            if ((v > 0) != pos) return false;          // человек почти всегда "гуляет" в обе стороны
        }
        double[] acc = new double[n - 1];
        for (int i = 0; i < n - 1; i++) acc[i] = y[i + 1] - y[i];
        if (std(acc, mean(acc)) < auraSmoothStd) return true;       // постоянное ускорение
        double[] ratio = new double[n - 1];
        for (int i = 0; i < n - 1; i++) ratio[i] = y[i + 1] / y[i];
        double rm = mean(ratio);
        return rm > 0.2 && rm < 0.97 && std(ratio, rm) < 0.02;      // постоянный коэффициент затухания (lerp)
    }

    private static double mean(double[] a) {
        double s = 0;
        for (double v : a) s += v;
        return s / a.length;
    }

    private static double std(double[] a, double m) {
        double s = 0;
        for (double v : a) s += (v - m) * (v - m);
        return Math.sqrt(s / a.length);
    }

    /** НОД для вещественных чисел с допуском на погрешность float. */
    private static double gcd(double a, double b) {
        while (Math.abs(b) > 0.0005) {
            double t = a % b;
            a = b;
            b = t;
        }
        return a;
    }

    /** Минимальная дистанция до цели с учётом её недавних позиций (компенсация пинга). */
    private double lagCompDist(Player attacker, Entity target, Vector eyeVec, double current) {
        if (!(target instanceof Player tp)) return current;
        Data td = data.get(tp.getUniqueId());
        if (td == null) return current;
        long now = System.currentTimeMillis();
        long window = Math.min(attacker.getPing(), 300) + 100;
        double hw = target.getWidth() / 2.0, h = target.getHeight();
        double best = current;
        for (int i = 0; i < td.ht.length; i++) {
            if (td.ht[i] == 0 || now - td.ht[i] > window) continue;
            double cx = Math.max(td.hx[i] - hw, Math.min(eyeVec.getX(), td.hx[i] + hw));
            double cy = Math.max(td.hy[i], Math.min(eyeVec.getY(), td.hy[i] + h));
            double cz = Math.max(td.hz[i] - hw, Math.min(eyeVec.getZ(), td.hz[i] + hw));
            double ddx = eyeVec.getX() - cx, ddy = eyeVec.getY() - cy, ddz = eyeVec.getZ() - cz;
            double dd = Math.sqrt(ddx * ddx + ddy * ddy + ddz * ddz);
            if (dd < best) best = dd;
        }
        return best;
    }

    /** Взмахи руки: нужны для NoSwing и Accuracy. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onSwing(PlayerAnimationEvent e) {
        if (!auraOn || e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player p = e.getPlayer();
        Data d = data(p);
        long now = System.currentTimeMillis();
        if (now - d.lastSwingTime > 4000) {
            d.swings = 0;
            d.hitCount = 0;
        }
        d.lastSwingTime = now;
        if (d.hitSwingPending && now - d.lastHitTime < 250) d.hitSwingPending = false;

        // Accuracy: почти все взмахи попадают по игрокам
        if (auraAcc && ++d.swings >= auraAccWindow) {
            if (!d.bypass && d.hitCount >= d.swings * auraAccRatio && !skip(p, d)) {
                heuristic(p, d, 8, "AuraAccuracy", String.format("попаданий %d из %d взмахов", d.hitCount, d.swings));
            }
            d.swings = 0;
            d.hitCount = 0;
        }
    }

    // ================= Phase / NoSlow =================

    private void checkPhase(Player p, Data d, Location from, Location to, World w,
                            double dx, double dy, double dz) {
        // 1) игрок оказался внутри твёрдого блока, хотя до этого был снаружи
        if (phaseInside && (to.getBlockX() != from.getBlockX() || to.getBlockY() != from.getBlockY()
                || to.getBlockZ() != from.getBlockZ())) {
            if (insideSolid(w, to.getX(), to.getY(), to.getZ())
                    && !insideSolid(w, from.getX(), from.getY(), from.getZ())) {
                flag(p, d, "Phase", 3.0, "вошёл в блок");
                return;
            }
        }
        // 2) за одно движение прошёл сквозь блок
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist > phaseRayMin && dist < 12.0) {
            if (insideSolid(w, from.getX(), from.getY(), from.getZ())) return;
            Location start = from.clone().add(0, 0.9, 0);
            Vector dir = new Vector(dx, dy, dz).normalize();
            RayTraceResult r = w.rayTraceBlocks(start, dir, dist, FluidCollisionMode.NEVER, true);
            if (r != null && r.getHitPosition().distance(start.toVector()) < dist - 0.3) {
                flag(p, d, "Phase", 3.0, String.format("сквозь блок (%.1f бл. за тик)", dist));
            }
        }
    }

    /** Пересекается ли нижняя часть тела игрока с коллизией блока (учитывает плиты, ступени, заборы). */
    private boolean insideSolid(World w, double x, double y, double z) {
        double e = 0.25;
        BoundingBox pb = new BoundingBox(x - e, y + 0.1, z - e, x + e, y + 0.6, z + e);
        int x0 = (int) Math.floor(pb.getMinX()), x1 = (int) Math.floor(pb.getMaxX());
        int y0 = (int) Math.floor(pb.getMinY()), y1 = (int) Math.floor(pb.getMaxY());
        int z0 = (int) Math.floor(pb.getMinZ()), z1 = (int) Math.floor(pb.getMaxZ());
        for (int bx = x0; bx <= x1; bx++) {
            for (int by = y0; by <= y1; by++) {
                for (int bz = z0; bz <= z1; bz++) {
                    if (!w.isChunkLoaded(bx >> 4, bz >> 4)) continue;
                    Block b = w.getBlockAt(bx, by, bz);
                    if (b.isPassable()) continue;
                    Material m = b.getType();
                    if (m == Material.SCAFFOLDING || m == Material.BIG_DRIPLEAF
                            || m == Material.POINTED_DRIPSTONE) continue;
                    if (b.getCollisionShape().overlaps(pb.clone().shift(-bx, -by, -bz))) return true;
                }
            }
        }
        return false;
    }

    /** NoSlow: на земле бежит быстро, хотя ест / натягивает лук / держит щит. */
    private void checkNoSlow(Player p, Data d, Location to, boolean steadyGround, double dx, double dz) {
        if (!steadyGround || !p.isHandRaised() || usingSpyglass(p)) {
            d.noSlowTicks = 0;
            return;
        }
        double h = Math.hypot(dx, dz);
        boolean over = false;
        if (h > noSlowMax && !Tag.ICE.isTagged(blockUnder(to))) {
            over = h > noSlowMax * speedLimit(p, to) / maxHorizontal;
        }
        if (over) {
            if (++d.noSlowTicks >= noSlowNeed) {
                flag(p, d, "NoSlow", 1.5, String.format("%.2f б/тик при использовании предмета", h));
                d.noSlowTicks = 0;
            }
        } else if (d.noSlowTicks > 0) {
            d.noSlowTicks--;
        }
    }

    private boolean usingSpyglass(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.SPYGLASS
                || p.getInventory().getItemInOffHand().getType() == Material.SPYGLASS;
    }

    // ================= Velocity (AntiKnockback) =================

    private void verifyKb(Player p) {
        if (!p.isOnline()) return;
        Data d = data.get(p.getUniqueId());
        if (d == null || !d.kbPending) return;
        d.kbPending = false;
        if (d.bypass || p.isDead() || p.isInsideVehicle() || p.isGliding() || tps < minTps) return;
        if (d.kbMax >= d.kbMag * kbMinRatio) return;          // отбрасывание сработало
        Location loc = p.getLocation();
        if (specialMedium(p, loc)) return;                    // вода, паутина, лианы...
        // упёрся в блок - сместиться и не мог
        Vector dir = new Vector(d.kbDx, 0, d.kbDz);
        if (p.getWorld().rayTraceBlocks(loc.clone().add(0, 0.9, 0), dir, 1.5,
                FluidCollisionMode.NEVER, true) != null) return;
        flag(p, d, "Velocity", 2.5, String.format("отбрасывание %.2f, сдвиг %.2f", d.kbMag, d.kbMax));
    }

    // ================= Scaffold / FastPlace / Nuker =================

    /** Смотрит ли игрок на блок (с запасом). */
    private boolean lookingAt(Player p, Block b, double expand) {
        BoundingBox box = b.getBoundingBox();
        if (box.getVolume() <= 0) return true;
        Location eye = p.getEyeLocation();
        return box.clone().expand(expand).rayTrace(eye.toVector(), eye.getDirection(), 8.0) != null;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (!scaffoldOn) return;
        Player p = e.getPlayer();
        Data d = data(p);
        if (skip(p, d)) return;
        long now = System.currentTimeMillis();

        // FastPlace
        d.places.addLast(now);
        while (!d.places.isEmpty() && now - d.places.peekFirst() > 1000) d.places.pollFirst();
        if (d.places.size() > scaffoldMaxPlaces) {
            e.setCancelled(true);
            flag(p, d, "FastPlace", 1.5, "блоков/сек: " + d.places.size());
            return;
        }

        // Scaffold: блок поставлен на другой блок, на который игрок не смотрит
        if (scaffoldLook) {
            Block against = e.getBlockAgainst();
            if (!against.isLiquid() && e.getBlockPlaced().getType() != Material.LILY_PAD
                    && !lookingAt(p, against, scaffoldExpand)) {
                e.setCancelled(true);
                flag(p, d, "Scaffold", 2.0, "ставит блок, не глядя на него");
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (!nukerOn) return;
        Player p = e.getPlayer();
        Data d = data(p);
        if (skip(p, d)) return;
        Block b = e.getBlock();
        long now = System.currentTimeMillis();
        long key = ((long) (b.getX() & 0x3FFFFFF) << 38) | ((long) (b.getZ() & 0x3FFFFFF) << 12) | (b.getY() & 0xFFF);

        // 1) несколько разных блоков за один тик
        if (now - d.lastBreakTime < 25 && d.lastBreakKey != key) {
            e.setCancelled(true);
            flag(p, d, "Nuker", 2.0, "несколько блоков за тик");
            return;
        }
        d.lastBreakTime = now;
        d.lastBreakKey = key;

        // 2) частота
        d.breaks.addLast(now);
        while (!d.breaks.isEmpty() && now - d.breaks.peekFirst() > 1000) d.breaks.pollFirst();
        if (d.breaks.size() > nukerMaxBreaks) {
            e.setCancelled(true);
            flag(p, d, "Nuker", 1.5, "блоков/сек: " + d.breaks.size());
            return;
        }

        // 3) дальность, взгляд, стена
        Location eye = p.getEyeLocation();
        Vector eyeVec = eye.toVector();
        Vector center = b.getBoundingBox().getCenter();
        double centerDist = center.distance(eyeVec);
        if (centerDist > nukerMaxDist) {
            e.setCancelled(true);
            flag(p, d, "Nuker", 2.0, String.format("дальность %.1f", centerDist));
            return;
        }
        if (nukerLook && !lookingAt(p, b, nukerExpand)) {
            e.setCancelled(true);
            flag(p, d, "Nuker", 2.0, "ломает блок, не глядя на него");
            return;
        }
        if (nukerWall && centerDist > 1.5) {
            Vector dir = center.clone().subtract(eyeVec).normalize();
            RayTraceResult r = p.getWorld().rayTraceBlocks(eye, dir, centerDist,
                    FluidCollisionMode.NEVER, true);
            if (r != null && r.getHitBlock() != null && !r.getHitBlock().equals(b)
                    && centerDist - r.getHitPosition().distance(eyeVec) > 1.0) {
                e.setCancelled(true);
                flag(p, d, "Nuker", 2.0, "ломает блок через другой блок");
            }
        }
    }

    // ================= AutoTotem / InvMove =================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onResurrect(EntityResurrectEvent e) {
        if (e.getEntity() instanceof Player p) data(p).popTime = System.currentTimeMillis();
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSwapHand(PlayerSwapHandItemsEvent e) {
        checkTotemSpeed(e.getPlayer());
    }

    private void checkTotemSpeed(Player p) {
        Data d = data(p);
        if (!totemOn || d.bypass || d.popTime == 0) return;
        long now = System.currentTimeMillis();
        long sincePop = now - d.popTime;
        if (sincePop > 2000) return;
        // вычитаем пинг: человеку нужно время на реакцию сверх сетевой задержки
        double reaction = sincePop - Math.min(p.getPing(), 500);
        if (reaction < totemMinMs) {
            flag(p, d, "AutoTotem", 2.0, String.format("реакция ~%.0f мс", Math.max(reaction, 0)));
            d.popTime = 0;
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onInvClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Data d = data(p);
        if (d.bypass || p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR) return;
        long now = System.currentTimeMillis();

        // AutoTotem через инвентарь
        if (e.getClick() == ClickType.SWAP_OFFHAND || e.getSlot() == 40) checkTotemSpeed(p);

        // InvMove: клики в инвентаре на полной скорости движения
        if (invMoveOn && tps >= minTps && d.wasGround && now - d.lastMove < 120 && d.lastH > invMoveSpeed
                && now > d.graceUntil && !p.isInsideVehicle() && !p.isInWater() && !p.isGliding()
                && !Tag.ICE.isTagged(blockUnder(p.getLocation()))) {
            if (now - d.invWindow > 1500) {
                d.invWindow = now;
                d.invCount = 0;
            }
            if (++d.invCount >= invMoveClicks) {
                flag(p, d, "InvMove", 1.5, String.format("клики на ходу (%.2f б/тик)", d.lastH));
                d.invCount = 0;
            }
        }
    }

    // ================= прочие события =================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Data d = data(p);
        d.bypass = p.hasPermission("sparkguard.bypass");
        grace(d, joinGrace);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent e) {
        Player p = e.getPlayer();
        Data d = data(p);
        // AntiKnockback: запоминаем ожидаемое отбрасывание и проверим его чуть позже
        if (kbOn && !d.kbPending && !skip(p, d)) {
            Vector v = e.getVelocity();
            double mag = Math.hypot(v.getX(), v.getZ());
            if (mag >= kbMinVel) {
                Location loc = p.getLocation();
                d.kbPending = true;
                d.kbMag = mag;
                d.kbMax = 0;
                d.kbDx = v.getX() / mag;
                d.kbDz = v.getZ() / mag;
                d.kbSx = loc.getX();
                d.kbSz = loc.getZ();
                long delay = 8L + Math.min(p.getPing(), 400) / 50;
                Bukkit.getScheduler().runTaskLater(this, () -> verifyKb(p), delay);
            }
        }
        grace(d, 2500);   // взрывы, wind charge, отбрасывание
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        Data d = data(e.getPlayer());
        grace(d, 1500);
        d.kbPending = false;
        d.timer = 0;
        Location t = e.getTo();
        if (t != null) setSafe(d, t.getWorld(), t);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        grace(data(e.getPlayer()), 1500);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        data.remove(e.getPlayer().getUniqueId());
        alertsOff.remove(e.getPlayer().getUniqueId());
    }

    // ================= команды =================

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] args) {
        if (!s.hasPermission("sparkguard.admin")) {
            s.sendMessage(color("&cНет прав."));
            return true;
        }
        String help = prefix + "/sg reload | /sg alerts | /sg vl <игрок> | /sg status | /sg debug";
        if (args.length == 0) {
            s.sendMessage(color(help));
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "reload" -> {
                loadSettings();
                s.sendMessage(color(prefix + "Конфиг перезагружен."));
            }
            case "alerts" -> {
                if (s instanceof Player p) {
                    if (alertsOff.remove(p.getUniqueId())) {
                        s.sendMessage(color(prefix + "Оповещения &aвключены"));
                    } else {
                        alertsOff.add(p.getUniqueId());
                        s.sendMessage(color(prefix + "Оповещения &cвыключены"));
                    }
                }
            }
            case "vl" -> {
                if (args.length < 2) {
                    s.sendMessage(color(help));
                    return true;
                }
                Player t = Bukkit.getPlayerExact(args[1]);
                Data d = t == null ? null : data.get(t.getUniqueId());
                if (d == null) {
                    s.sendMessage(color(prefix + "Игрок не найден."));
                } else if (d.vl.isEmpty()) {
                    s.sendMessage(color(prefix + t.getName() + ": нарушений нет."));
                } else {
                    StringBuilder sb = new StringBuilder(prefix + t.getName() + ": ");
                    d.vl.forEach((k, v) -> sb.append("&e").append(k).append("&f=").append(String.format("%.1f", v)).append(" "));
                    s.sendMessage(color(sb.toString()));
                }
            }
            case "status" -> s.sendMessage(color(prefix + String.format(
                    "TPS≈%.1f, игроков под наблюдением: %d, профиль: %s, только оповещение: %s",
                    tps, data.size(), profile, alertOnly)));
            case "debug" -> {
                debug = !debug;
                s.sendMessage(color(prefix + "Debug-лог ударов: " + (debug ? "&aвключён" : "&cвыключен")));
            }
            default -> s.sendMessage(color(help));
        }
        return true;
    }
}
