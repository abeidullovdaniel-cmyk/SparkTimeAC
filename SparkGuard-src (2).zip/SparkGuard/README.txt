Сборка:  mvn clean package   (нужны JDK 21 и Maven)
Jar: target/SparkGuard-1.3.jar -> в папку plugins сервера.
Команды: /sg reload, /sg alerts, /sg vl <игрок>
